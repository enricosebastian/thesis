                    
                # random_trash_x.remove(trash_i)
                # random_trash_y.remove(trash_i)