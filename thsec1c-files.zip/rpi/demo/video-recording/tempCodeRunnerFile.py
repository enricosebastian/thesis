cap = cv2.VideoCapture(0)

# fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
# writer = cv2.VideoWriter("recording.mp4", fourcc, 24.0, (640, 480))