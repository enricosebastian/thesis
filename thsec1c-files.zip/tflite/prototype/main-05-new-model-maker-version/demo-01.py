# Based on https://github.com/tensorflow/examples/tree/master/tensorflow_examples/lite/model_maker

from tflite_model_maker import image_classifier
from tflite_model_maker.image_classifier import DataLoader

print("Hello world")