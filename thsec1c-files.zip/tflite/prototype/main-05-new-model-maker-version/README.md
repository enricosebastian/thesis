# Welcome to the main model maker
After git pulling, don't forget to create an `images` folder. You can do that by simply entering 

```mkdir images```

in the `thesis/tflite/prototype/main-05-new-model-maker-version` folder